<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

include "setting.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postData = file_get_contents("php://input");
    $data = json_decode($postData, true);

    // Check if all required parameters are present
    $requiredParams = ['callsign', 'teacher', 'remark', 'gradelist'];
    foreach ($requiredParams as $param) {
        if (!isset($data[$param])) {
            http_response_code(300);
            echo json_encode(array('status' => '300', 'code' => 'Missing required values'));
            exit;
        }
    }

    $token = hash('sha256', $data['token']);
    if ($token !== $token_Correct) {
        http_response_code(505);
        echo json_encode(array('status' => '505', 'code' => 'Invalid token'));
        exit;
    }

    // Prepare SQL statement based on available parameters
    $updateColumns = [];
    $bindParams = [];
    $bindTypes = "";

    foreach ($requiredParams as $param) {
        if (isset($data[$param])) {
            $updateColumns[] = "$param=?";
            $bindParams[] = &$data[$param];
            $bindTypes .= 's';
        }
    }
    $bindParams[] = &$data['callsign']; // Add callsign as the last parameter
    $bindTypes .= 's';

    $sqlQuery = "UPDATE atcdisplay SET " . implode(', ', $updateColumns) . " WHERE callsign=?";

    // Prepare and execute SQL statement
    $sqlFlight = $conn->prepare($sqlQuery);
    if ($sqlFlight) {
        $bindParams = array_merge([$bindTypes], $bindParams);
        call_user_func_array(array($sqlFlight, 'bind_param'), $bindParams);
        $sqlFlight->execute();

        if ($sqlFlight->affected_rows > 0) {
            http_response_code(200);
            echo json_encode(array('status' => '200', 'data' => $data));
            exit;
        } else {
            http_response_code(404);
            echo json_encode(array('status' => '404', 'code' => 'No rows affected'));
            exit;
        }
    } else {
        http_response_code(500);
        echo json_encode(array('status' => '500', 'code' => 'Internal server error'));
        exit;
    }
} else {
    http_response_code(500);
    echo json_encode(array('status' => '500', 'code' => 'Invalid request method'));
    exit;
}

