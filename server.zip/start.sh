#!/bin/bash
# There's nothing interesting......

while true; do
    php autoload.php
    php VAWhazzup.php
    sleep 10
done
