<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './mailserver/src/Exception.php';
require './mailserver/src/PHPMailer.php';
require './mailserver/src/SMTP.php';

function Captcha($email,$user){
    $mail = new PHPMailer(true);
    try {
        // 服务器配置
        $mail->CharSet = "UTF-8";
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'smtp.qq.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'amstudio@qq.com';
        $mail->Password = 'ojxeivkzyineddaj';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('amstudio@qq.com', 'AV-Studio');
        $mail->addAddress(strval($email), strval($user));
        $mail->addReplyTo('3208629021@qq.com', 'Ariven');

        // 生成验证码
        $verificationCode = mt_rand(100000, 999999);

        $mail->isHTML(true);
        $mail->Subject = 'AVMCV2.0注册验证码';

        $mail->Body = '<style>
                    h1 {
                        
                        font-family: Arial, Helvetica, sans-serif;
                    }
                    </style>
                    <h1>欢迎注册AFCS V3.0 !</h1>
                    <h1>验证码：' . $verificationCode . '</h1>';
        $mail->AltBody = '如果邮件客户端不支持HTML则显示此内容';

        $mail->send();
        return $verificationCode;
        // 将验证码存储在数据库或会话中以供后续验证使用

    } catch (Exception $e) {
        return 0;
    }

}

function welcome($email,$user){
    $mail = new PHPMailer(true);
    try {
        // 服务器配置
        $mail->CharSet = "UTF-8";
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'smtp.qq.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'amstudio@qq.com';
        $mail->Password = 'ojxeivkzyineddaj';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('amstudio@qq.com', 'AM-Studio');
        $mail->addAddress(strval($email), strval($user));
        $mail->addReplyTo('3208629021@qq.com', 'Ariven');

        $mail->isHTML(true);
        $mail->Subject = 'AFCS3.0 欢迎邮件';
        $mail->Body = '<style>
                    h1 {
                        
                        font-family: Arial, Helvetica, sans-serif;
                    }
                    </style>
                    <h1>欢迎使用AFCS V3.0 !</h1>
                    <h1>AM-Studio 祝您玩的愉快!</h1>';
        $mail->AltBody = 'AM-Studio 祝您玩的愉快!';

        $mail->send();

    } catch (Exception $e) {

    }

}



?>