#!/bin/bash
PYTHONPATH=. twistd -n pyfsd