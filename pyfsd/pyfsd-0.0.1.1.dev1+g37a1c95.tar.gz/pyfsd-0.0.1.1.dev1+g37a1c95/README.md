# PyFSD
基于Twisted的[FSD](https://github.com/kuroneko/fsd)协议9的实现。  
[使用&插件开发文档](https://gamecss.github.io/pyfsd)

## Todo
### 多服务器协议
一点还没做啊!谁会需要多服务器啊???

## 开源协议
MIT License  
Copyright (c) 2023 gamecss  
无附加条款。
